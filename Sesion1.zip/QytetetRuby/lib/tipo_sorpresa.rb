#encoding: utf-8 

module ModeloQytetet

module TipoSorpresa
    PAGARCOBRAR = :PagarCobrar
    IRACASILLA = :IrACasilla
    PORCASAHOTEL = :PorCasaHotel
    PORJUGADOR = :PorJugador
    SALIRCARCEL = :SalirCarcel
end

end